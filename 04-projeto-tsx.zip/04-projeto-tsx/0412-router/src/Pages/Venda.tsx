import React from "react";

const Venda = () => {
  return <div>Venda</div>;
};

export default Venda;
