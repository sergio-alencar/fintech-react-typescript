import React from "react";
import DateRange from "./DateRange";

const Header = () => {
  return (
    <div>
      <DateRange />
    </div>
  );
};

export default Header;
