import React from "react";

const Sidenav = () => {
  return <div>Sidenav</div>;
};

export default Sidenav;
